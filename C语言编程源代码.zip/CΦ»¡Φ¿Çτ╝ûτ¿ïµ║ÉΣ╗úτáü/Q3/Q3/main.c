//
//  main.c
//  Q3
//
//  Created by ljcmhw on 2021/8/2.
//

#include <stdio.h>
int main()
{
    char a[20];
    char b[100];
    int i,j,k=1;
    fgets(b, 100, stdin);
    for (i=0; i<100; i++) {
        if (b[i]==' '&&k==1) {
            continue;
        }
        else if(k==1){
            for(k=0;;k++)
            {
                a[k]=b[i+k];
                if (b[i+k+1]=='\0'||b[i+k+1]==' '||b[i+k+1]=='\n')
                {
                break;
            }
        }
        }
        else break;
    }
    for (j=0; j<=k; j++) {
        if (a[j]==' '||a[j]=='\n'||a[j]=='\t') {
            break;
        }
        
        printf("%c",a[j]);
    }
    printf("\n");
    return 0;
}
