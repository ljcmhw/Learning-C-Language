//
//  main.c
//  Q6
//
//  Created by ljcmhw on 2021/8/2.
//

#include <stdio.h>
#include<string.h>
int is_within(char a,char*b);
int main()
{
    char str[100];
    char k;
    int p;
    printf("Please enter the string:\n");
    fgets(str, 100, stdin);
    printf("Please enter the letter you want to search:\n");
    scanf("%c",&k);
    p=is_within(k, str);
    if (p==1) {
        printf("The letter is in the string.\n");
    }
    if (p==0) {
        printf("Can't find the letter in the string.\n");}
    return 0;
}
int is_within(char a,char*b)
{
    int i,j=0;
    for (i=0; i<strlen(b); i++) {
        if (a==*(b+i)) {
            j=1;
            break;
        }
        else j=0;
    }
    return j;
}
