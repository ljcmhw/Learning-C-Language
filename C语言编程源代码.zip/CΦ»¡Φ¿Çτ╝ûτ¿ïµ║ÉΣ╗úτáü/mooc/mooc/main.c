//
//  main.c
//  mooc
//
//  Created by ljcmhw on 2021/3/26.
//
#include <stdio.h>
void seperate(float a)
{
    int i=0,c,d,e,f,g;int b[20];
    for (e=0; ; e++) {
        f=(int)a;if((a-f)==0)break;a=a*10;
    }g=a;
    for (i=0; ;i++) {
        b[i]=g%10;
        c=(int)g/10; g=c;d=i;
        if(g<1)break;
    }
    for (i=d; i>=0; i--) {
        if(i==0){printf("%d\n",b[i]);break;}
        printf("%d ",b[i]);
    }
}
int main()
{
    void seperate(float a);
    float p;
    scanf("%f",&p);
    seperate(p);
}
