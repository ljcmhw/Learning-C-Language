//
//  main.c
//  Q13
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include<string.h>
int main(int argc,char*argv[])
{
    int a;
    a=argc-1;
    while (argc>1) {
        printf("%s",argv[a]);
        a--;
        if (a==1) {
            break;
        }
    }
    return 0;
}
