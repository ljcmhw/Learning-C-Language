//
//  main.c
//  Chapter 8
//
//  Created by ljcmhw on 2021/6/27.
//

#include <stdio.h>
#include <string.h>
int main()
{   void exchange(char*m1,char*m2,char*m3);
    void trade(char*n1,char*n2);
    char a[40];char b[40];char c[40];
    scanf("%s",a);
    scanf("%s",b);
    scanf("%s",c);
    char*p=a;char*q = b;char*r = c;
    exchange(p,q,r);
    printf("The order is:\n%s\n%s\n%s\n",p,q,r);
    return 0;
}
void exchange(char*m1,char*m2,char*m3)
{   void trade(char*n1,char*n2);
    if(strcmp(m1,m2)>0)trade(m1, m2);
    if(strcmp(m1,m3)>0)trade(m1, m3);
    if(strcmp(m2,m3)>0)trade(m2, m3);
}
void trade(char*n1,char*n2)
{
    char e[40];
    strcpy(e, n1);strcpy(n1, n2);strcpy(n2, e);
}
