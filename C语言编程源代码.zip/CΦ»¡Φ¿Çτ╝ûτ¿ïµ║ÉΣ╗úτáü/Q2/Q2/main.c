//
//  main.c
//  Q2
//
//  Created by ljcmhw on 2021/8/2.
//

#include <stdio.h>
char*s(int size,char m[size]);
int main()
{
    char*a;
    int n;
    printf("How many characters you want to enter:\n");
    scanf("%d",&n);
    getchar();
    char b[n+1];
    fgets(b,n+1,stdin);
    a=s(n+1,b);
    printf("\n");
    printf("%p\n",a);
    return 0;
}
char*s(int size,char m[size])
{
    int i=0;
    int g;
    for(i=0;i<size;i++){
        if(m[i]==EOF||m[i]==' '||m[i]=='\t'||m[i]=='\n')
    {
        break;}
       else if (i==(size-1)) {
            break;
        }
    }
    for (g=0;g<=i;g++) {
        printf("%c",m[g]);
    }
    return &m[0];
}
