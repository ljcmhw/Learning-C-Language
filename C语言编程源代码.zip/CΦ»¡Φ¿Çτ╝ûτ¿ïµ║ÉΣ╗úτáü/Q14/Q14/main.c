//
//  main.c
//  Q14
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
double ave2(double s,int num);
void ave1(int row,int column,double a[*][*]);
double max(int row,int column,double c[row][column]);
double ave3(int row,int column,double b[row][column]);
int main()
{
    int r=2,c=3;
    double array[r][c];
    int x,y;
    for (x=0; x<r; x++) {
        for (y=0; y<c; y++) {
            scanf("%lf",&array[x][y]);
        }
    }
    ave1(r,c,array);
    printf("The total average is %lf.\n",ave3(r,c,array));
    printf("The maximum value of the array is %lf.\n",max(r,c,array));
    return 0;
}
void ave1(int row,int column,double a[row][column])
{
    int i,j;
    double sum;
    double aver;
    double(*k)[column];
    for (i=0,k=a; i<row; i++,k++) {
        sum=0;
        for (j=0; j<column; j++) {
            sum+=*(*k+j);
        }
        aver=ave2(sum,column);
        printf("The average of row %d is %f.\n",i+1,aver);
    }
}
double ave2(double s,int num)
    {
        double average;
        average=s/num;
        return average;
    }
double ave3(int row,int column,double b[row][column])
{
    int i,j;
    double sum_=0;
    double (*g)[column];
    for (i=0,g=b;i<row; i++,g++) {
        for (j=0; j<column; j++) {
            sum_+=*(*g+j);
        }
    }
    return sum_/(row*column);
}
double max(int row,int column,double c[row][column])
{
    double *m;
    int i,j;
    m=c[0];
    for (i=0; i<row; i++) {
        for (j=0; j<column; j++) {
            if (*m<c[i][j]) {
                m=&c[i][j];
            }
        }
    }
    return *m;
}
