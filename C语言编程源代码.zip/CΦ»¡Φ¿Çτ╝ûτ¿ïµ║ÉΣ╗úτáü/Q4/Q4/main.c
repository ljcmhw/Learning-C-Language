//
//  main.c
//  Q4
//
//  Created by ljcmhw on 2021/8/2.
//

#include <stdio.h>
int main()
{
    char b[100];
    int i,k,j=0;
    printf("Please enter the string:\n");
    fgets(b, 100, stdin);
    printf("How many letters you want to print:\n");
    scanf("%d",&k);
    for (i=0; i<100; i++) {
        if (b[i]==' '||b[i]=='\t') {
            if (j>0) {
                break;
            }
            continue;
        }
        else if(b[i]=='\0'||b[i]=='\n'){
            break;
        }
        j++;
        printf("%c",b[i]);
        if (j==k) {
            break;
        }
    }
    printf("\n");
    return 0;
}
