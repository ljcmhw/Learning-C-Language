//
//  main.c
//  Q12
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include<ctype.h>
int main()
{
    char s1[100];
    int a=0,b=0,c=0,d=0,e=0,i;
    printf("Please enter the string.\n");
    fflush(stdin);
    fgets(s1, 100, stdin);
    for(i=0;;i++){
        if(*(s1+i)!=EOF){
        if (*(s1+i)==' ') {
            a++;
            continue;
        }
        if (isupper(*(s1+i))) {
            b++;
            continue;
        }
        if (islower(*(s1+i))) {
            c++;
            continue;
        }
        if (ispunct(*(s1+i))) {
            d++;
            continue;
        }
        if (isdigit(*(s1+i))) {
            e++;
            continue;
        }}
        else break;
    }
    printf("有%d个大写字母，%d个小写字母，%d个单词，%d个标点符号，%d个数字字符.\n",b,c,a,d,e);
    return 0;
}
