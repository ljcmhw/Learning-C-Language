//
//  main.c
//  P14Q6
//
//  Created by ljcmhw on 2021/3/4.
//

#include <stdio.h>

int main()
{
    int max(int x,int y,int z);
    int a,b,c,m;
    printf("a=");
    scanf("%d",&a);
    printf("b=");
    scanf("%d",&b);
    printf("c=");
    scanf("%d",&c);
    m=max(a,b,c);
    printf("max=%d\n",m);
    return 0;
}
    
    int max(int x,int y,int z)
    {
        int t;
        if(x>y)
          if(x>z)t=x;
          else t=z;
        else if(y>z)t=y;
        else t=z;
        return(t);
    }



