//
//  main.c
//  P14Q4
//
//  Created by ljcmhw on 2021/3/4.
//

#include <stdio.h>
int main()
{
    printf ("Hello World!\n");
    return 0;
}
