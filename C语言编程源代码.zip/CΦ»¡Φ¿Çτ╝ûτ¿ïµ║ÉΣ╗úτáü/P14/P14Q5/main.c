//
//  main.c
//  P14Q5
//
//  Created by ljcmhw on 2021/3/4.
//

#include <stdio.h>
int main()
{
    printf("*****\n\n");
    printf("  *****\n\n");
    printf("    *****\n\n");
    printf("      *****\n");
    return 0;
}
