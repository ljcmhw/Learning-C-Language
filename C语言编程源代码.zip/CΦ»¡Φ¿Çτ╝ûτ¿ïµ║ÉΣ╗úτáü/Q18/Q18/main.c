//
//  main.c
//  Q18
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#define Dunbar 150
int main()
{
    int fri=5;
    int week;
    for(week=1;;week++)
    {
        fri=(fri-1)*2;
        printf("Week %d,Doctor has %d friends.\n",week,fri);
        if(fri>Dunbar)break;
    }
    return 0;
}
