//
//  main.c
//  P80Q6
//
//  Created by ljcmhw on 2021/3/25.
//

#include <stdio.h>

int main()
{
    int c1=67,c2=104,c3=105,c4=110,c5=97;
    putchar(c1);
    putchar(c2);
    putchar(c3);
    putchar(c4);
    putchar(c5);
    putchar('\n');
    c1=c1+4;c2=c2+4;c3=c3+4;c4=c4+4;c5=c5+4;
    printf("%c%c%c%c%c\n",c1,c2,c3,c4,c5);
}
