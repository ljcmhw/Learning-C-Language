//
//  main.c
//  P80Q7
//
//  Created by ljcmhw on 2021/3/25.
//

#include <stdio.h>
#include <math.h>
int main()
{
    float r=1.5,h=3,a,b,c,d,e,pi=3.14;
    scanf("r=%f,h=%f",&r,&h);
    a=2*pi*r;
    b=pi*r*r;
    c=4*pi*r*r;
    d=4/3*pi*r*r*r;
    e=pi*r*r*h;
    printf("圆周长=%1.2f\n圆面积=%2.2f\n圆球表面积=%2.2f\n圆球体积=%2.2f\n圆柱体积=%2.2f\n",a,b,c,d,e);
    return 0;
}
