//
//  main.c
//  P80Q4
//
//  Created by ljcmhw on 2021/3/24.
//

#include <stdio.h>

int main()
{
    int c1,c2;
    c1=97;
    c2=98;
    printf("c1=%c,c2=%c\n",c1,c2);
    printf("c1=%d,c2=%d\n",c1,c2);
    return 0;
}
