//
//  main.c
//  P80Q1
//
//  Created by ljcmhw on 2021/3/23.
//

#include <stdio.h>
#include <math.h>
int main()
{
    double r,n,p;
    r=0.07;
    n=10;
    p=pow(1+r,n);
    printf("%1.2f%%\n",p);
    return 0;
}
