//
//  main.c
//  P80Q3
//
//  Created by ljcmhw on 2021/3/24.
//

#include <stdio.h>
#include <math.h>
int main()
{
    float d=3e5,p=6e4,r=0.01,m;
    m=log(p/(p-d*r))/log(1+r);
    printf("%1.1f\n",m);
    return 0;
}
