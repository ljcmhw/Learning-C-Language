//
//  main.c
//  P80Q8
//
//  Created by ljcmhw on 2021/3/25.
//

#include <stdio.h>
int main()
{
    char c1,c2;
    c1=getchar();
    c2=getchar();
    putchar(c1);
    putchar('\n');
    printf("%d\n",c2);
}
