//
//  main.c
//  P80Q5
//
//  Created by ljcmhw on 2021/3/25.
//

#include <stdio.h>

int main()
{
    int a,b;
    float x,y;
    char c1,c2;
    scanf("a=%db=%d",&a,&b);
    scanf("%f%e",&x,&y);
    scanf("%c%c",&c1,&c2);
    return 0;
}
