//
//  main.c
//  Q11
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include <string.h>
#define price1 2.05
#define price2 1.15
#define price3 1.09
int main()
{
    char letter,letter1;
    int judge;
    float art1=0,art=0,art2=0,beet1=0,beet=0,beet2=0,carrot1=0,carrot=0,carrot2=0,d=0,e=0,f=0;
    float price,pound,price_;
    printf("Please enter a letter(a or b or c or q):\n");
    scanf("%c",&letter);
    switch (letter) {
        case 'a':
            printf("Please enter the pounds of artichokes:\n");
            scanf("%f",&art);
            art1+=art;
            break;
        case 'b':
            printf("Please enter the pounds of beets:\n");
            scanf("%f",&beet);
            beet1+=beet;
            break;
        case 'c':
            printf("Please enter the pounds of carrots:\n");
            scanf("%f",&carrot);
            carrot1+=carrot;
            break;
        case 'q':
            printf("Quit.\n");
            break;
        default:
            break;
    }
    while(letter=='a'||letter=='b'||letter=='c'){
        printf("Would you like to add something?(Please choose 1.yes or 2.no)\n");
            scanf("%d",&judge);
        getchar();
        if (judge==1) {
            printf("Please enter a letter(a or b or c or q):\n");
            scanf("%c",&letter1);
            getchar();
            if(letter1=='a'){
                printf("Please enter the pounds of artichokes:\n");
                scanf("%f",&art2);
                getchar();
                d=art1;
                art1=d+art2;
            }
            if(letter1=='b'){
                printf("Please enter the pounds of beets:\n");
                scanf("%f",&beet2);
                getchar();
                e=beet1;
                beet1=e+beet2;
            }
            if (letter1=='c') {
                printf("Please enter the pounds of carrots:\n");
                scanf("%f",&carrot2);
                getchar();
                f=carrot1;
                carrot1=f+carrot2;
            }
            }
        if (judge==2) {
            break;
        }}
    printf("The price of artichokes is 2.05$ per pound.\n");
    printf("The price of beets is 1.15$ per pound.\n");
    printf("The price of carrots is 1.09$ per pound.\n");
    printf("The total pound of artichokes,beets and carrots are:%.3f,%.3f,%.3f\n",art1,beet1,carrot1);
    price=price1*art1+price2*beet1+price3*carrot1;
    printf("The price of the order is:%.3f\n",price);
    if (price>=100) {
        price*=0.95;
        printf("You can enjoy the 5%% discount(the total pound is over 100)\n");
    }
    pound=art1+beet1+carrot1;
    if (pound<=5.0) {
        price_=6.5;
        printf("The freight is 6.5$.\n");
    }
    else if(pound<=20.0){
        price_=14.0;
        printf("The freight is 14.0$.\n");
    }
    else {price_=14+(pound-20)*0.5;
        printf("The freight is %.1f$.\n",price_);}
    printf("The total price is(include freight): %.3f$\n",price+price_);
    return 0;
}
