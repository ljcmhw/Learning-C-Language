//
//  main.c
//  Q16
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include <math.h>
int main()
{
    float Daphne,Deirdre;
    int year=1;
    do{
        Daphne=100+10*year;
        Deirdre=100*pow(1.05,year);
        year++;
    }while (Daphne>=Deirdre);
    printf("After %d years,Deirder's investment will exceed Daphne's.\nDeirdre's will be:%.3f$,and Daphne's will be %.3f$.\n",year,Deirdre,Daphne);
    return 0;
}
