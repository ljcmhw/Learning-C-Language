//
//  main.c
//  Q1
//
//  Created by ljcmhw on 2021/8/2.
//

#include <stdio.h>
char*s(char m[]);
int main()
{
    char*a;
    char b[100];
    a=s(b);
    printf("%p\n",a);
    return 0;
}
char*s(char m[])
{
    int i=0;
    while((m[i]=getchar())!=EOF)
    {  i++;
    }
    return &m[0];
}

