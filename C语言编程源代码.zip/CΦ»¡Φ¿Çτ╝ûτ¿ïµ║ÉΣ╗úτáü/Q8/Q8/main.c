//
//  main.c
//  Q8
//
//  Created by ljcmhw on 2021/8/2.
//
#include<stdio.h>
#include<string.h>
char*string_in(char*s1,char*s2);
int main()
{
    char a[100];
    char b[100];
    char*c;
    do{
        printf("Please enter the string1(enter # to quit):\n");
        fflush(stdin);
        fgets(a,100,stdin);
        if (a[0]=='#') {
            break;
        }
        printf("Please enter the string2 you want to find in string1:\n");
        fflush(stdin);
        fgets(b, 100, stdin);
        c=string_in(a,b);
        printf("The address of the string2 is %p",c);
        printf("\n");
    }while(1);
    return 0;
}
char*string_in(char*s1,char*s2)
{
    int i,j;
    char*s3=NULL;
    int k=(int)strlen(s2);
    for (i=0; i<(int)strlen(s1); i++) {
        if (s1[i]==s2[0]) {
            for (j=1;j<k;j++) {
                if (*(s1+j+i)==*(s2+j)) {
                    if(j+1<k)
                    continue;
                    else {
                        s3=s1+i;
                    }
                }
                else break;
            }
        }
    }
    return s3;
}
