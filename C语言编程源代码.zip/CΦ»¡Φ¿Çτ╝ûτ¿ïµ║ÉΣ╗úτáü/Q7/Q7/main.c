//
//  main.c
//  Q7
//
//  Created by ljcmhw on 2021/8/2.
//

#include <stdio.h>
#include<string.h>
char*mystrncpy(char*s1,char*s2,int n);
int main()
{
    int k,p;
    char a[100];
    char*b;
    do{
        printf("Please enter a string(enter # to quit):\n");
        fflush(stdin);
        fgets(a, 100, stdin);
        if (a[0]=='#') {
            break;
        }
        printf("Please enter how many letters you want to copy:\n");
        scanf("%d",&k);
        char c[k];
        b=mystrncpy(c, a, k);
        for (p=0; p<k; p++) {
            printf("%c",*(b+p));
        }
        printf("\n");
    }while(1);
    return 0;
}
char*mystrncpy(char*s1,char*s2,int n)
{
    int i;
    for (i=0; i<n; i++) {
        *(s1+i)=*(s2+i);}
    return s1;
}

