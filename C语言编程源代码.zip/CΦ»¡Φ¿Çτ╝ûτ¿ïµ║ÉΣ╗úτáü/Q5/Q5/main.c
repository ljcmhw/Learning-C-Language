//
//  main.c
//  Q5
//
//  Created by ljcmhw on 2021/8/2.
//

#include <stdio.h>
#include<string.h>
int main()
{
    char a[100];
    char b;
    char*c;
    int i;
    do{
        printf("Please enter a string(enter # to quit):\n");
        fflush(stdin);
        fgets(a, 100, stdin);
        if (a[0]=='#') {
            break;
        }
        printf("Enter the letter you want to find:\n");
        scanf("%c",&b);
        for (i=0; i<100; i++) {
            if (a[i]==b) {
                c=&a[i];
                printf("%p\n",c);
                break;
            }
            else if(i==99&&a[i]!=b){
                c=NULL;
                printf("%p\n",c);
                break;
            }
        }
    }while(1);
    return 0;
}
