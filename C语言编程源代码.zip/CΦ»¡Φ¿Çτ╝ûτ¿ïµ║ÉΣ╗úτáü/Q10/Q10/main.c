//
//  main.c
//  Q10
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include<string.h>
void delete(char*s1);
int main()
{
    char m[100];
    do{
    printf("Please enter the string(enter return to quit):\n");
        fflush(stdin);
        fgets(m, 100, stdin);
        if (m[0]=='\n') {
            break;
        }
        delete(m);
    }while(1);
    return 0;
}
void delete(char*s1)
{
    char a=' ';
    int i,j,k=(int)strlen(s1);
    for (i=0; i<strlen(s1); i++) {
        if (a==*(s1+i)) {
            for (j=i; j<strlen(s1); j++) {
                *(s1+j)=*(s1+j+1);
            }
            k--;
        }
    }
    printf("%s\n",s1);
}

