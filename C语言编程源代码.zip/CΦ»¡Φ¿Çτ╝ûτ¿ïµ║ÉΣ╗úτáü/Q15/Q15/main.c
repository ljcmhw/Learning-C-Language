//
//  main.c
//  Q15
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include <string.h>
int main()
{
    char ch[225];
    char c;
    int j=0;
    c=getchar();
    while ((c=getchar())!='\n') {
        ch[j]=c;
        j++;
    }
    for (j=j-1;j>=0 ; j--) {
        printf("%c",ch[j]);
    }
    printf("\n");
    return 0;
}
