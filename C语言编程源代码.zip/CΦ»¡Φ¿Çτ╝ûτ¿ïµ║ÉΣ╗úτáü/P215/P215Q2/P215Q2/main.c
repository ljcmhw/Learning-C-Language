//
//  main.c
//  P215Q2
//
//  Created by ljcmhw on 2021/5/8.
//

#include <stdio.h>

int main()
{
    int matrix(int array[3][3],int x,int y);
    int i=0,j=0;int array[i][j];
    int Array[i][j];
    for(i=0;i<=2;i++){
    
    for(j=0;j<2;j++){
        scanf("%d",&array[i][j]);
    }   if(j==2){scanf("%d/n",&array[i][j]);}
    }
    Array[i][j]=matrix(array,i,j);
    for(i=0;i<=2;i++){
        for(j=0;j<2;j++){
        printf("%d ",Array[i][j]);}
        if(j==2){printf("%d\n",Array[i][j]);}}
return 0;
}
int matrix(int array[3][3],int x,int y)
{
    int p[3][3];
    for(x=0;x<=2;x++){
        for(y=0;y<=2;y++){
            p[x][y]=array[y][x];}}
            return p[x][y];
}
