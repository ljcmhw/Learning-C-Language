//
//  main.c
//  实验台
//
//  Created by ljcmhw on 2021/5/9.
//

#include <stdio.h>
int main()
{
    int n,m;
    scanf("%d",&n);
    m=(n%10)*100+(n/10%10)*10+(n/100);
    printf("%03d\n",m);
    return 0;
}
