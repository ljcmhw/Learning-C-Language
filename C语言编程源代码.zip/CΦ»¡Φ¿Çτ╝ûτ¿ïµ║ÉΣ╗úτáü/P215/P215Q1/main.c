//
//  main.c
//  215
//
//  Created by ljcmhw on 2021/5/8.
//

#include <stdio.h>

int main()
{
    int max(int f,int g);
    int min(int b,int d);
    int m,n,x,y;
    scanf("%d %d",&m,&n);
    x=max(m,n);
    y=min(m,n);
    printf("%d %d\n",x,y);
    return 0;
}

int max(int f,int g)
{
    int a,c,e;
    if(f>=g){a=f;c=g;
    }
    else {a=g;c=f;}
    while (a%c!=0) {
        e=a%c;a=c;c=e;
    }
    return (c);
}

int min(int b,int d)
{   int max(int a,int c);
    int k,z;
    z=max(b,d);
    k=(b*d)/z;
    return (k);
}
