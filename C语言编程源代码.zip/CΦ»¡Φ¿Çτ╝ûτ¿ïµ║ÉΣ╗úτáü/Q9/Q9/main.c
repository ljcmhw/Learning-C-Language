//
//  main.c
//  Q9
//
//  Created by ljcmhw on 2021/8/5.
//

#include <stdio.h>
#include<string.h>
void strc(char*s1)
{
    int a=0;
    char temp;
    int b=(int)strlen(s1)-1;
    while (a<b) {
        temp=s1[a];
        s1[a]=s1[b];
        s1[b]=temp;
        ++a;
        --b;
    }
        printf("%s",s1);
}
int main()
{
    char m[100];
    do{
        printf("Please enter the string(enter # to quit):\n");
        fflush(stdin);
        fgets(m,100,stdin);
        if (m[0]=='#') {
            break;
        }
        strc(m);
        printf("\n");
    }while (1);
    return 0;
}
