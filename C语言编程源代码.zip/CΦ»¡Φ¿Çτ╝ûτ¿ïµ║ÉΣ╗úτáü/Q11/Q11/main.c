//
//  main.c
//  Q11
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include<string.h>
char * s_gets(char * st, int n);
int main()
{
    int choose;
    int j=10;
    int k;
    char a[9][100];
    int i=0;
    printf("Please enter some strings(at most ten):\n");
    for (i=0; i<j; i++) {
        s_gets(a[0],100);
        k=(int)strlen(a[i]);
        *(a[i]+k-1)='\0';
        if (i==(j-1))break;
    }
    printf("Please choose a method to print:\n");
    printf("1.initial order\t\t2.Order by ASCII\n");
    printf("3.Order by length\t\t4.Order by the first word\n");
    printf("5.Quiz\n");
    scanf("%d",&choose);
    switch (choose) {
        case 1:
            break;
            
        default:
            break;
    }
    return 0;
}
char * s_gets(char * st, int n)
{
char * ret_val;
int i = 0;
ret_val = fgets(st, n, stdin);
if (ret_val)
{
while (st[i] != '\n' && st[i] != '\0')
i++;
if (st[i] == '\n')
st[i] = '\0';
else
while (getchar() != '\n')
continue;
}
return ret_val;
}
