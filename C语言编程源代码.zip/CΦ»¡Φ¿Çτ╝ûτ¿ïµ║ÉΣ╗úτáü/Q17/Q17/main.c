//
//  main.c
//  Q17
//
//  Created by ljcmhw on 2021/8/6.
//

#include <stdio.h>
#include <math.h>
int main()
{
    float money=1e06;
    int year;
    for (year=1;;year++) {
        money=money+money*0.08-1e05;
        if(money<=0)break;
    }
    printf("After %d years,there is no money left.\n",year);
    return 0;
}
